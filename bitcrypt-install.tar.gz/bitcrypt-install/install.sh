cp ./files/bitcrypt.desktop /usr/share/applications/

cp ./files/bitcrypticon16.png /usr/share/icons/hicolor/16x16/apps/bitcrypt.png
cp ./files/bitcrypticon24.png /usr/share/icons/hicolor/24x24/apps/bitcrypt.png
cp ./files/bitcrypticon32.png /usr/share/icons/hicolor/32x32/apps/bitcrypt.png
cp ./files/bitcrypticon48.png /usr/share/icons/hicolor/48x48/apps/bitcrypt.png
cp ./files/bitcrypticon64.png /usr/share/icons/hicolor/64x64/apps/bitcrypt.png
cp ./files/bitcrypticon128.png /usr/share/icons/hicolor/128x128/apps/bitcrypt.png

chmod 777 ./bitcrypt
cp ./bitcrypt /usr/local/bin/bitcrypt

