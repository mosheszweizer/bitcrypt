bitcrypt
Encryption hides text in pictures

Bitcrypt is easy to use. There are only two objectives. The first is to put some text into a picture. The second is to retrieve it. Thus, to operate the program, one needs a picture, some text to be encoded, and an encryption key. The steps are as follows:

To encrypt:

Select a bitmap image (it must be either 24 or 32 bits deep)
Either upload from a file or type into the editor some text you wish to hide in the image
Type an encryption key you wish to use (it needs to be at least eight characters long)
Press the encrypt button
The program takes your text and processes it with the Rijndael cipher. The outcome of this process is shown in the editor. The thus encrypted text is 'written' into the picture you have selected. At the completion of the process, a popup message asks you to save the encrypted image, which you need to do as a last step.

To decrypt:

Select an encrypted image
Type the encryption key
Press the decrypt button The decrypted text is shown in the editor. You can export it if you wish using the provided button.
Notes: a) The image must be a bitmap. If you have a different format, you can use any image editor (for example, GIMP) to convert it/export it to this format. b) The key may be any combination of ASCII characters. That is, the program should be able to accept anything that you can type on the keyboard c) The Rijndael cipher enlarges text. Therefore, you may need a larger image to accommodate this. If the image is too small, a popup message tells you by how much. You may take this into account when selecting a larger picture.

-------------------------------------------------------------------
BitCrypt is written in Pascal and the file stored here was compiled on an AMD® Ryzen processor running Ubuntu 20.04.5 LTS. You can download the file and test if it runs on your Linux installation.

INSTALL
Bitcrypt has been compiled with FPC compiler which staticly links all dependancies. Therefore one should not need to import any additional components to run bitcrypt. 

To install, 
Download the compressed bitcrypt-install file from this directory and uncompress it.
Examine install.sh file to see the intended installation destinations. Then run
sudo ./install.sh

-------------------------------------------------------------------

Static linking
FPC compiles and links a static executable by default. That means it tells the linker to put all .o files of the project and all packages into one big executable.
Advantages:
No external dependencies.
Disadvantages:
No code is shared between different programs on the same computer.
You can not load/unload a plugin.
Bitcrypt was compiled with the following command:
<?xml version="1.0" encoding="UTF-8"?>
<CONFIG>
  <Compiler Value="/usr/bin/fpc" Date="1574718682"/>
  <Params Value=" -MObjFPC -Scghi -Cg -O1 -l -vewnhibq -Fi/home/moshe/devel/pascal/bitcrypt/lib/x86_64-linux -Fu/home/moshe/.lazarus/onlinepackagemanager/packages/richmemo/lib/x86_64-linux -Fu/usr/lib/lazarus/2.0.6/lcl/units/x86_64-linux/gtk2 -Fu/usr/lib/lazarus/2.0.6/lcl/units/x86_64-linux -Fu/usr/lib/lazarus/2.0.6/components/lazutils/lib/x86_64-linux -Fu/home/moshe/.lazarus/onlinepackagemanager/packages/DCPcrypt/lib/x86_64-linux -Fu/usr/lib/lazarus/2.0.6/packager/units/x86_64-linux -Fu/home/moshe/devel/pascal/bitcrypt/ -FU/home/moshe/devel/pascal/bitcrypt/lib/x86_64-linux/ -FE/home/moshe/devel/pascal/bitcrypt/ -o/home/moshe/devel/pascal/bitcrypt/bitcrypt -dLCL -dLCLgtk2 bitcrypt.lpr"/>
</CONFIG>








