BitCrypt is a stand-alone application.
That means one can copy the program to any folder, USB device etc. and run it from there. It should run as it does not depend on any external components or libraries. However, you may like to create a folder for it on your computer and create a shortcut on your desktop to ease program invocation. 

This version of the program is free to use without any restrictions.
This version of the program is as powerful as any of the previous versions, so please enjoy.

The program was compiled on a system as specified below.
AMD Ryzen 3 running 64-bit operating system, x64-based processor Windows 10 Home edition.

There is also a Linux version of the same program. You may download it from the Authors' website or the GitHub.com repository.


Author:             www.moshe-szweizer.com
Bitcrypt:           bitcrypt.moshe-szweizer.com
The Privacy Tool:   www.theprivacytool.com
Linux version:      github.com/mosheszweizer/bitcrypt